#include "sudoku.h"

#include <stdio.h>
#include <stdbool.h>
#include <math.h>

#define SIZE 9

// 检查某一行是否有效
int check_row(int grid[SIZE][SIZE], int row) {
    bool vis[SIZE + 1] = {};
    for (int i = 0; i < SIZE; i++) {
        if (vis[grid[row][i]]) return 0;
        vis[grid[row][i]] = true;
    }
    return 1;
}

// 检查某一列是否有效
int check_column(int grid[SIZE][SIZE], int col) {
    bool vis[SIZE + 1] = {};
    for (int i = 0; i < SIZE; i++) {
        if (vis[grid[i][col]]) return 0;
        vis[grid[i][col]] = true;
    }
    return 1;
}

// 检查3x3小方格是否有效
int check_block(int grid[SIZE][SIZE], int start_row, int start_col) {
    bool vis[SIZE + 1] = {};
    for (int i = start_row; i < start_row + sqrt(SIZE); i++) {
        for (int j = start_col; j < start_col + sqrt(SIZE); j++) {
            if (vis[grid[i][j]]) return 0;
            vis[grid[i][j]] = true;
        }
    }
    return 1;
}